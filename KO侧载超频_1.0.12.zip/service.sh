#!/system/bin/sh

MODDIR=${0%/*}
STATE_FILE="$MODDIR/config/state"
MAX_ATTEMPTS=20
ATTEMPT=1

while [ "$ATTEMPT" -le "$MAX_ATTEMPTS" ]; do
    # Ticket timestamps are invalid while Android still reports the epoch.
    NOW=$(date +%s 2>/dev/null)
    case "$NOW" in
        ''|*[!0-9]*) NOW=0 ;;
    esac
    if [ "$NOW" -ge 1700000000 ]; then
        sh "$MODDIR/bin/oc_guard.sh" service || true
    fi
    if [ "$(cat "$STATE_FILE" 2>/dev/null | tr -d '\r\n ')" = ready ]; then
        exit 0
    fi
    sleep 15
    ATTEMPT=$((ATTEMPT + 1))
done

# Keep the final failure fail-closed after the bounded retry window.
sh "$MODDIR/bin/oc_guard.sh" service
