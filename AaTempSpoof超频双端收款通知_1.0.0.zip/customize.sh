#!/system/bin/sh
MODDIR="${MODPATH:-${0%/*}}"
PKG="com.aatempspoof.payment"
COMPONENT="$PKG/$PKG.NotificationListener"
APK="$MODDIR/bin/AaTempSpoofNotifier.apk"
BASE_DIR="/data/adb/aa-overclock-payment"

ui_print "- AaTempSpoof 超频双端收款通知"
ui_print "- 通知将分别发送到 AaTempSpoof 与独立超频服务器"
set_perm_recursive "$MODDIR" 0 0 0755 0644
set_perm "$MODDIR/customize.sh" 0 0 0755
set_perm "$MODDIR/service.sh" 0 0 0755
set_perm "$MODDIR/action.sh" 0 0 0755
set_perm "$MODDIR/uninstall.sh" 0 0 0755
set_perm "$MODDIR/bin/sponsor-listener" 0 0 0755
set_perm "$APK" 0 0 0644
[ -s "$APK" ] && [ -x "$MODDIR/bin/sponsor-listener" ] || { ui_print "! 缺少通知监听 APK 或 native listener"; exit 1; }
mkdir -p "$BASE_DIR/aatempspoof" "$BASE_DIR/overclock" 2>/dev/null || true
chmod 0700 "$BASE_DIR" "$BASE_DIR/aatempspoof" "$BASE_DIR/overclock" 2>/dev/null || true
for pid in $(pidof sponsor-listener 2>/dev/null || true); do
  cmdline="$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)"
  case "$cmdline" in *sponsor-listener*) kill "$pid" 2>/dev/null || true ;; esac
done
tmp_apk="/data/local/tmp/AaTempSpoof-Notifier-Dual.apk"
rm -f "$tmp_apk" 2>/dev/null || true
cp -f "$APK" "$tmp_apk" 2>/dev/null || exit 1
chmod 0644 "$tmp_apk" 2>/dev/null || true
pm install -r --user 0 "$tmp_apk" >/dev/null 2>&1 || { rm -f "$tmp_apk"; ui_print "! 通知监听 APK 安装失败"; exit 1; }
rm -f "$tmp_apk" 2>/dev/null || true
pm enable --user 0 "$PKG" >/dev/null 2>&1 || true
cmd package unstop --user 0 "$PKG" >/dev/null 2>&1 || true
cmd appops set --user 0 "$PKG" RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true
cmd appops set --user 0 "$PKG" RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true
dumpsys deviceidle whitelist +"$PKG" >/dev/null 2>&1 || true
current="$(settings get secure enabled_notification_listeners 2>/dev/null)"
[ "$current" = "null" ] && current=""
case ":$current:" in *":$COMPONENT:"*) ;; *) next="$COMPONENT"; [ -n "$current" ] && next="$current:$COMPONENT"; settings put secure enabled_notification_listeners "$next" >/dev/null 2>&1 || true; cmd notification allow_listener "$COMPONENT" 0 >/dev/null 2>&1 || true ;; esac
/system/bin/sh "$MODDIR/service.sh" --once >/dev/null 2>&1 || true
ui_print "- 双端通知监听已安装"
exit 0
