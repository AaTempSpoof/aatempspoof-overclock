#!/system/bin/sh
PKG="com.aatempspoof.payment"
COMPONENT="$PKG/$PKG.NotificationListener"
OLD_PKG="cn.ppps.forwarder"
RUNTIME_DIR="/data/adb/aa-overclock-payment"
for pidfile in "$RUNTIME_DIR/notification-service.pid" "$RUNTIME_DIR/aatempspoof/sponsor-listener.pid" "$RUNTIME_DIR/overclock/sponsor-listener.pid"; do
    if [ -s "$pidfile" ]; then
        pid="$(sed -n '1p' "$pidfile" 2>/dev/null)"
        case "$pid" in ''|*[!0-9]*) ;; *) kill "$pid" 2>/dev/null || true ;; esac
    fi
done
current="$(settings get secure enabled_notification_listeners 2>/dev/null)"
if [ "$current" != "null" ] && [ -n "$current" ]; then
    cleaned="$(printf '%s' "$current" | tr ':' '\n' | awk -v c="$COMPONENT" '$0 != c && $0 != ""' | paste -sd: -)"
    settings put secure enabled_notification_listeners "$cleaned" >/dev/null 2>&1 || true
fi
cmd notification disallow_listener "$COMPONENT" 0 >/dev/null 2>&1 || true
pm uninstall --user 0 "$PKG" >/dev/null 2>&1 || true
pm uninstall --user 0 "$OLD_PKG" >/dev/null 2>&1 || true
rm -rf "$RUNTIME_DIR" 2>/dev/null || true
exit 0
