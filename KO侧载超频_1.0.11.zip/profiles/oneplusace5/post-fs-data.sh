#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
LOG_FILE="$CONFIG_DIR/runtime.log"
STATE_FILE="$CONFIG_DIR/state"
KO="$MODDIR/bin/oneplus_ace5_display_120_144_auto.ko"
KO_NAME=oneplus_ace5_display_120_144_auto

mkdir -p "$CONFIG_DIR" 2>/dev/null

log_line()
{
	printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE"
}

write_state()
{
	printf '%s\n' "$1" > "$STATE_FILE"
	log_line "state=$1"
}

read_param()
{
	cat "/sys/module/$KO_NAME/parameters/$1" 2>/dev/null
}

log_line "start module=$KO_NAME max_refresh=144"

if [ ! -r "$KO" ]; then
	write_state ko_missing
	exit 0
fi

if [ -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	APPLIED=$(read_param applied)
	CACHE=$(read_param cache_applied)
	log_line "already_loaded applied=$APPLIED cache_applied=$CACHE"
	if [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; then
		write_state already_loaded
	else
		write_state already_loaded_unverified
	fi
	exit 0
fi

TRIES=0
while [ ! -d /sys/module/msm_drm ] && [ "$TRIES" -lt 30 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ ! -d /sys/module/msm_drm ]; then
	log_line "msm_drm_not_ready waited=${TRIES}s"
	write_state msm_drm_not_ready
	exit 0
fi

log_line "msm_drm_ready waited=${TRIES}s"

if grep -q "^${KO_NAME} " /proc/modules 2>/dev/null; then
	log_line "module_present_in_proc"
	write_state already_loaded
	exit 0
fi

if [ -x /system/bin/toybox ]; then
	/system/bin/toybox insmod "$KO" >> "$LOG_FILE" 2>&1
	RC=$?
else
	/system/bin/insmod "$KO" >> "$LOG_FILE" 2>&1
	RC=$?
fi

if [ "$RC" -ne 0 ] && [ ! -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	log_line "insmod_failed rc=$RC"
	write_state insmod_failed
	exit 0
fi

TRIES=0
while [ ! -r "/sys/module/$KO_NAME/parameters/applied" ] && [ "$TRIES" -lt 5 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

APPLIED=$(read_param applied)
CACHE=$(read_param cache_applied)
MODE_COUNT=$(read_param mode_count_after)
FAILURE=$(read_param failure_code)
log_line "insmod_rc=$RC applied=$APPLIED cache_applied=$CACHE mode_count_after=$MODE_COUNT failure_code=$FAILURE"

if { [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; } &&
	{ [ "$CACHE" = Y ] || [ "$CACHE" = 1 ]; }; then
	write_state loaded
else
	write_state loaded_unverified
fi

exit 0
