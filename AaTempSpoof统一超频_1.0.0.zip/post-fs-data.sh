#!/system/bin/sh

MODDIR=${0%/*}
sh "$MODDIR/bin/oc_guard.sh" boot
