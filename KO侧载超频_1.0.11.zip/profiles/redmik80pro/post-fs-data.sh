#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
LOG_FILE="$CONFIG_DIR/runtime.log"
STATE_FILE="$CONFIG_DIR/state"
KO="$MODDIR/bin/miro_display_120_144_165_180_auto.ko"
KO_NAME=miro_oc_display

mkdir -p "$CONFIG_DIR" 2>/dev/null

log_line()
{
	printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE"
}

write_state()
{
	printf '%s\n' "$1" > "$STATE_FILE"
	log_line "state=$1"
}

read_param()
{
	cat "/sys/module/$KO_NAME/parameters/$1" 2>/dev/null
}

find_dsi_node()
{
	for p in /sys/class/drm/card*-DSI-*/status; do
		[ -e "$p" ] && { printf '%s\n' "$p"; return 0; }
	done
	return 1
}

log_line "start module=$KO_NAME max_refresh=180"
# ---------- LTPO / 空闲自动降帧禁用 ----------
# sun 平台 init.qti.display_boot.sh 在同为 post-fs-data 阶段的异步服务里把 vendor.display.*
# 空闲降帧开关全部打开（dynamic_sf_idle 默认放行），不触碰屏幕时会自动回落低档。
# 这里用 resetprop 覆盖，并在后台补偿 60 秒压住与 qti 脚本的启动竞态（最后一次写入生效）。
# config/ltpo_disable 写 0 可关闭本功能；原始属性值首次运行记录到 config/ltpo_props_original。
# 1.0.3 追加 MI-SF（libmisurfaceflinger.so）空闲降帧开关：TP idle / QuickIdle / idle 默认帧 / AOD 120Hz TE。

LTPO_ORIG_FILE="$CONFIG_DIR/ltpo_props_original"
LTPO_PROP_LIST="ro.surface_flinger.use_content_detection_for_refresh_rate vendor.display.disable_dynamic_sf_idle vendor.display.enable_allow_idle_fallback vendor.display.enable_optimal_refresh_rate vendor.display.enable_idle_content_fps_hint vendor.display.disable_content_fps_hint ro.vendor.display.touch.idle.enable ro.vendor.mi_sf.touch.idle.enable ro.vendor.display.quickidle.enable ro.vendor.display.primary_idle_refresh_rate ro.vendor.display.idle_default_fps ro.vendor.mi_sf.te_120hz_in_aod_mode persist.vendor.mi_sf.force_skip_idle_fps persist.vendor.disable_idle_fps"

find_resetprop()
{
	for p in /data/adb/ksu/bin/resetprop /data/adb/magisk/resetprop /data/adb/ap/bin/resetprop; do
		[ -x "$p" ] && { printf '%s\n' "$p"; return 0; }
	done
	command -v resetprop 2>/dev/null
}

ltpo_set_prop()
{
	CMD=$1; NAME=$2; VALUE=$3; QUIET=$4
	"$CMD" -n "$NAME" "$VALUE" >/dev/null 2>&1
	NOW=$(getprop "$NAME" 2>/dev/null)
	if [ "$NOW" != "$VALUE" ]; then
		"$CMD" "$NAME" "$VALUE" >/dev/null 2>&1
		NOW=$(getprop "$NAME" 2>/dev/null)
	fi
	[ "$NOW" = "$VALUE" ] && return 0
	[ "$QUIET" = 1 ] || log_line "ltpo=set_failed name=$NAME value=$VALUE got=$NOW"
	return 1
}

ltpo_apply()
{
	QUIET=$1
	CMD=$(find_resetprop)
	if [ -z "$CMD" ]; then
		[ "$QUIET" = 1 ] || log_line "ltpo=resetprop_not_found"
		return 1
	fi
	if [ ! -s "$LTPO_ORIG_FILE" ]; then
		: > "$LTPO_ORIG_FILE"
		for P in $LTPO_PROP_LIST; do
			V=$(getprop "$P" 2>/dev/null)
			[ -n "$V" ] || V=__UNSET__
			printf '%s=%s\n' "$P" "$V" >> "$LTPO_ORIG_FILE"
		done
	fi
	OK=1
	ltpo_set_prop "$CMD" ro.surface_flinger.use_content_detection_for_refresh_rate false "$QUIET" || OK=0
	ltpo_set_prop "$CMD" vendor.display.disable_dynamic_sf_idle 1 "$QUIET" || OK=0
	ltpo_set_prop "$CMD" vendor.display.enable_allow_idle_fallback 0 "$QUIET" || OK=0
	ltpo_set_prop "$CMD" vendor.display.enable_optimal_refresh_rate 0 "$QUIET" || OK=0
	ltpo_set_prop "$CMD" vendor.display.enable_idle_content_fps_hint 0 "$QUIET" || OK=0
	ltpo_set_prop "$CMD" vendor.display.disable_content_fps_hint 1 "$QUIET" || OK=0
	ltpo_set_prop "$CMD" ro.vendor.display.touch.idle.enable false "$QUIET" || OK=0
	ltpo_set_prop "$CMD" ro.vendor.mi_sf.touch.idle.enable false "$QUIET" || OK=0
	ltpo_set_prop "$CMD" ro.vendor.display.quickidle.enable false "$QUIET" || OK=0
	ltpo_set_prop "$CMD" ro.vendor.display.primary_idle_refresh_rate 165 "$QUIET" || OK=0
	ltpo_set_prop "$CMD" ro.vendor.display.idle_default_fps 165 "$QUIET" || OK=0
	ltpo_set_prop "$CMD" ro.vendor.mi_sf.te_120hz_in_aod_mode false "$QUIET" || OK=0
	ltpo_set_prop "$CMD" persist.vendor.mi_sf.force_skip_idle_fps 1 "$QUIET" || OK=0
	ltpo_set_prop "$CMD" persist.vendor.disable_idle_fps 1 "$QUIET" || OK=0
	[ "$OK" = 1 ]
}

ltpo_watch()
{
	i=0
	while [ "$i" -lt 60 ]; do
		ltpo_apply 1
		sleep 1
		i=$((i + 1))
	done
	log_line "ltpo=reassert_done count=$i"
}

LTPO_DISABLE=1
if [ -r "$CONFIG_DIR/ltpo_disable" ]; then
	V=$(cat "$CONFIG_DIR/ltpo_disable" 2>/dev/null | tr -d '[:space:]')
	[ -n "$V" ] && LTPO_DISABLE=$V
fi

if [ "$LTPO_DISABLE" = 1 ]; then
	if ltpo_apply 0; then
		log_line "ltpo=disabled"
	else
		log_line "ltpo=apply_incomplete"
	fi
	ltpo_watch >> "$LOG_FILE" 2>&1 &
fi

if [ ! -r "$KO" ]; then
	write_state ko_missing
	exit 0
fi

if [ -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	APPLIED=$(read_param applied)
	log_line "already_loaded applied=$APPLIED stage=$(read_param stage)"
	if [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; then
		write_state already_loaded
	else
		write_state already_loaded_unverified
	fi
	exit 0
fi

TRIES=0
while [ ! -d /sys/module/msm_drm ] && [ "$TRIES" -lt 30 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ ! -d /sys/module/msm_drm ]; then
	log_line "msm_drm_not_ready waited=${TRIES}s"
	write_state msm_drm_not_ready
	exit 0
fi

log_line "msm_drm_ready waited=${TRIES}s"

if grep -q "^${KO_NAME} " /proc/modules 2>/dev/null; then
	log_line "module_present_in_proc"
	write_state already_loaded
	exit 0
fi

if [ -x /system/bin/toybox ]; then
	/system/bin/toybox insmod "$KO" probe_only=0 scale_bitclk=1 fix_transfer_time=1 fix_mdp_transfer=1 mdp_transfer_us=5600 fix_pixel_clock=1 dump_always=0 priv_dump_size=0 >> "$LOG_FILE" 2>&1
	RC=$?
else
	/system/bin/insmod "$KO" probe_only=0 scale_bitclk=1 fix_transfer_time=1 fix_mdp_transfer=1 mdp_transfer_us=5600 fix_pixel_clock=1 dump_always=0 priv_dump_size=0 >> "$LOG_FILE" 2>&1
	RC=$?
fi

if [ "$RC" -ne 0 ] && [ ! -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	log_line "insmod_failed rc=$RC"
	write_state insmod_failed
	exit 0
fi

# 面板对象的捕获挂在一次 display 探测上；探测同时用于刷新 connector 的模式列表，
# 必须在 SurfaceFlinger / 合成器启动前完成，系统才能枚举到 144/165。
TRIES=0
DSI_NODE=""
while [ "$TRIES" -lt 10 ]; do
	DSI_NODE=$(find_dsi_node) && break
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ -n "$DSI_NODE" ]; then
	echo detect > "$DSI_NODE" 2>>"$LOG_FILE"
	log_line "detect sent node=$DSI_NODE waited=${TRIES}s"
else
	log_line "dsi_node_missing waited=${TRIES}s"
fi

TRIES=0
while [ "$TRIES" -lt 15 ]; do
	APPLIED=$(read_param applied)
	{ [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; } && break
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ -n "$DSI_NODE" ]; then
	echo detect > "$DSI_NODE" 2>>"$LOG_FILE"
fi

APPLIED=$(read_param applied)
STAGE=$(read_param stage)
COUNT_BEFORE=$(read_param count_before)
COUNT_AFTER=$(read_param count_after)
FAILURE=$(read_param failure_code)
VERIFY=$(read_param verify_step)
log_line "insmod_rc=$RC applied=$APPLIED stage=$STAGE count=$COUNT_BEFORE->$COUNT_AFTER failure_code=$FAILURE verify_step=$VERIFY waited=${TRIES}s"

if [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; then
	write_state loaded
else
	write_state loaded_unverified
fi

exit 0
