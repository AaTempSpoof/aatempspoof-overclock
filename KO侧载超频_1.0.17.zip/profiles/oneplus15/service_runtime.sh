#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
STATE_FILE="$CONFIG_DIR/state"
LOG_FILE="$CONFIG_DIR/runtime.log"
MODE_RATES="60 90 120 144 165 180 185 188 190 195 199 200 215"
LTPO_CTL="$MODDIR/bin/ltpo_control.sh"
REFRESH_APPLY="$MODDIR/bin/refresh_apply.sh"
REFRESH_GUARD="$MODDIR/bin/refresh_guard"
GUARD_PID_FILE="$CONFIG_DIR/guard.pid"
RESTORE_PENDING_FILE="$CONFIG_DIR/vrr_setting_restore_pending"
ADFR_ENABLE_NODE=/sys/module/oneplus15_display_165_180_auto/parameters/adfr_lock_enable
ADFR_ACTIVE_NODE=/sys/module/oneplus15_display_165_180_auto/parameters/adfr_lock_active
GUARD_CHILD_PID=

rotate_runtime_log()
{
	[ -f "$LOG_FILE" ] || return 0
	LOG_SIZE=$(wc -c < "$LOG_FILE" 2>/dev/null) || return 0
	case "$LOG_SIZE" in
		''|*[!0-9]*) return 0 ;;
	esac
	[ "$LOG_SIZE" -le 1048576 ] && return 0
	mv -f "$LOG_FILE" "$LOG_FILE.1" 2>/dev/null || return 0
	: > "$LOG_FILE"
	chmod 0660 "$LOG_FILE" 2>/dev/null || true
}

write_state()
{
	printf '%s\n' "$1" > "$STATE_FILE"
	printf '%s event=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE"
}

numeric_pid()
{
	case "$1" in
		''|*[!0-9]*) return 1 ;;
		*) return 0 ;;
	esac
}

guard_process_matches()
{
	PID=$1
	numeric_pid "$PID" || return 1
	kill -0 "$PID" 2>/dev/null || return 1
	CMDLINE=$(tr '\0' ' ' < "/proc/$PID/cmdline" 2>/dev/null) || return 1
	case "$CMDLINE" in
		"$REFRESH_GUARD --module $MODDIR "*) return 0 ;;
		*) return 1 ;;
	esac
}

guard_pid()
{
	PID=$(sed -n '1p' "$GUARD_PID_FILE" 2>/dev/null | awk '{print $1}')
	guard_process_matches "$PID" || return 1
	printf '%s\n' "$PID"
}

guard_running()
{
	guard_pid >/dev/null
}

service_enabled()
{
	[ -d "$MODDIR" ] || return 1
	[ ! -e "$MODDIR/remove" ] || return 1
	[ ! -e "$MODDIR/disable" ] || return 1
	[ "$(sed -n '1p' "$CONFIG_DIR/enabled" 2>/dev/null)" = 1 ]
}

wait_guard_running()
{
	WAIT_TRY=0
	while [ "$WAIT_TRY" -lt 20 ]; do
		guard_running && return 0
		WAIT_TRY=$((WAIT_TRY + 1))
		sleep 0.1
	done
	return 1
}

start_guard()
{
	[ -x "$REFRESH_GUARD" ] || {
		printf '%s refresh_guard=missing\n' "$(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
		return 1
	}
	guard_running && return 0
	GUARD_CHILD_PID=
	START_ATTEMPT=1
	while [ "$START_ATTEMPT" -le 2 ]; do
		rm -f "$GUARD_PID_FILE" 2>/dev/null
		/system/bin/setsid "$REFRESH_GUARD" --module "$MODDIR" >> "$CONFIG_DIR/guard.log" 2>&1 &
		STARTED_PID=$!
		printf '%s refresh_guard=start_requested attempt=%s\n' \
			"$(date '+%Y-%m-%d %H:%M:%S')" "$START_ATTEMPT" >> "$LOG_FILE"
		if wait_guard_running; then
			RUNNING_PID=$(guard_pid)
			[ "$RUNNING_PID" = "$STARTED_PID" ] && GUARD_CHILD_PID=$STARTED_PID
			printf '%s refresh_guard=started attempt=%s\n' \
				"$(date '+%Y-%m-%d %H:%M:%S')" "$START_ATTEMPT" >> "$LOG_FILE"
			return 0
		fi
		guard_process_matches "$STARTED_PID" && kill -TERM "$STARTED_PID" 2>/dev/null
		wait "$STARTED_PID" 2>/dev/null || true
		printf '%s refresh_guard=start_failed attempt=%s\n' \
			"$(date '+%Y-%m-%d %H:%M:%S')" "$START_ATTEMPT" >> "$LOG_FILE"
		START_ATTEMPT=$((START_ATTEMPT + 1))
	done
	return 1
}

stop_guard()
{
	PID=$(guard_pid 2>/dev/null) || return 0
	kill -TERM "$PID" 2>/dev/null || return 0
	STOP_TRY=0
	while [ "$STOP_TRY" -lt 30 ] && guard_process_matches "$PID"; do
		sleep 0.1
		STOP_TRY=$((STOP_TRY + 1))
	done
}

watch_guard_lifecycle()
{
	WATCHED_PID=$1
	while service_enabled && guard_process_matches "$WATCHED_PID"; do
		sleep 3
	done
	service_enabled || {
		guard_process_matches "$WATCHED_PID" && kill -TERM "$WATCHED_PID" 2>/dev/null
	}
}

supervise_guard()
{
	RESTART_DELAY=2
	while service_enabled; do
		if ! guard_running; then
			if ! start_guard; then
				printf '%s refresh_guard=restart_failed retry_in=%s\n' \
					"$(date '+%Y-%m-%d %H:%M:%S')" "$RESTART_DELAY" >> "$LOG_FILE"
				sleep "$RESTART_DELAY"
				[ "$RESTART_DELAY" -ge 30 ] || RESTART_DELAY=$((RESTART_DELAY * 2))
				[ "$RESTART_DELAY" -le 30 ] || RESTART_DELAY=30
				continue
			fi
		fi

		RUNNING_PID=$(guard_pid 2>/dev/null) || continue
		if [ -n "$GUARD_CHILD_PID" ] && [ "$RUNNING_PID" = "$GUARD_CHILD_PID" ]; then
			GUARD_WAIT_STARTED=$(date '+%s')
			watch_guard_lifecycle "$RUNNING_PID" &
			WATCH_PID=$!
			wait "$RUNNING_PID" 2>/dev/null
			GUARD_EXIT=$?
			kill "$WATCH_PID" 2>/dev/null || true
			wait "$WATCH_PID" 2>/dev/null || true
			GUARD_CHILD_PID=
			GUARD_WAIT_ENDED=$(date '+%s')
			GUARD_UPTIME=$((GUARD_WAIT_ENDED - GUARD_WAIT_STARTED))
			[ "$GUARD_UPTIME" -ge 60 ] && RESTART_DELAY=2
		else
			sleep 5
			guard_running && continue
			GUARD_EXIT=unknown
		fi

		service_enabled || break
		printf '%s refresh_guard=unexpected_exit status=%s retry_in=%s\n' \
			"$(date '+%Y-%m-%d %H:%M:%S')" "$GUARD_EXIT" "$RESTART_DELAY" >> "$LOG_FILE"
		sleep "$RESTART_DELAY"
		[ "$RESTART_DELAY" -ge 30 ] || RESTART_DELAY=$((RESTART_DELAY * 2))
		[ "$RESTART_DELAY" -le 30 ] || RESTART_DELAY=30
	done
	stop_guard
	printf '%s refresh_guard=supervisor_stopped\n' \
		"$(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
}

trap 'stop_guard; exit 0' 1 2 15

rotate_runtime_log

if [ "${1:-}" = supervise ]; then
	supervise_guard
	exit 0
fi

SERVICE_MODE=verify
if [ -f "$RESTORE_PENDING_FILE" ]; then
	SERVICE_MODE=restore
elif [ "$(sed -n '1p' "$STATE_FILE" 2>/dev/null)" != pending:verify ]; then
	exit 0
fi

WAITED=0
while [ "$(getprop sys.boot_completed)" != 1 ] && [ "$WAITED" -lt 180 ]; do
	sleep 2
	WAITED=$((WAITED + 2))
done
[ "$(getprop sys.boot_completed)" = 1 ] || {
	write_state boot_timeout
	exit 0
}

printf '0\n' > "$CONFIG_DIR/game_active"
printf '0\n' > "$CONFIG_DIR/game_rate"
: > "$CONFIG_DIR/game_package"
printf '0\n' > "$CONFIG_DIR/app_active"
printf '0\n' > "$CONFIG_DIR/app_rate"
: > "$CONFIG_DIR/app_package"
[ -f "$CONFIG_DIR/app_rates" ] || : > "$CONFIG_DIR/app_rates"
/system/bin/settings put global oneplus15_display_game_active 0 >/dev/null 2>&1 || true
/system/bin/settings put global oneplus15_display_app_active 0 >/dev/null 2>&1 || true
GLOBAL_TARGET=$(sed -n '1p' "$CONFIG_DIR/target_hz" 2>/dev/null)
case "$GLOBAL_TARGET" in
	60|90|120|144|165|180|185|188|190|195|199|200|215)
		/system/bin/settings put global oneplus15_display_global_rate \
			"$GLOBAL_TARGET" >/dev/null 2>&1 || true
		;;
	*)
		GLOBAL_TARGET=188
		printf '188\n' > "$CONFIG_DIR/target_hz"
		/system/bin/settings put global oneplus15_display_global_rate \
			"$GLOBAL_TARGET" >/dev/null 2>&1 || true
		;;
esac

if [ "$SERVICE_MODE" = restore ]; then
	if [ -x "$LTPO_CTL" ]; then
		"$LTPO_CTL" restore
		write_state framework_setting_restore_completed
	else
		write_state framework_setting_restore_command_missing
	fi
	exit 0
fi

# The display driver must finish booting before ADFR state is changed.  The
# previous early write could stall panel initialization before SurfaceFlinger.
sleep 10
BOOT_PREP_STATE=ready
if [ ! -w "$ADFR_ENABLE_NODE" ]; then
	BOOT_PREP_STATE=adfr_lock_control_missing
elif ! printf '1\n' > "$ADFR_ENABLE_NODE" 2>>"$LOG_FILE"; then
	BOOT_PREP_STATE=adfr_lock_enable_failed
else
	ADFR_ACTIVE=$(cat "$ADFR_ACTIVE_NODE" 2>/dev/null)
	if [ "$ADFR_ACTIVE" != Y ] && [ "$ADFR_ACTIVE" != 1 ]; then
		BOOT_PREP_STATE=adfr_lock_verify_failed
	else
		printf '%s adfr_lock=enabled_after_boot property_id=47\n' \
			"$(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
	fi
fi

if [ -x "$LTPO_CTL" ]; then
	if ! "$LTPO_CTL" apply; then
		[ "$BOOT_PREP_STATE" = ready ] && BOOT_PREP_STATE=ltpo_runtime_apply_failed
	fi
else
	[ "$BOOT_PREP_STATE" = ready ] && BOOT_PREP_STATE=ltpo_control_missing
fi

sleep 5

mode_id()
{
	HZ="$1"
	printf '%s\n' "$MODE_SNAPSHOT" | sed -n -E \
		"s/.*\{id=([0-9]+),.*resolution=1272x2772, vsyncRate=${HZ}\.[0-9]+ Hz.*/\1/p" | head -n 1
}

MODE_SNAPSHOT=$(dumpsys SurfaceFlinger 2>/dev/null | awk '
	/Pacesetter Display / { in_display = 1 }
	in_display && /activeMode=/ { print; next }
	in_display && index($0, "resolution=1272x2772,") { print; next }
	in_display && /displayManagerPolicy=/ { exit }
')
MODE_VERIFY=ok
for HZ in $MODE_RATES; do
	ID=$(mode_id "$HZ")
	printf '%s detected_mode hz=%s id=%s\n' \
		"$(date '+%Y-%m-%d %H:%M:%S')" "$HZ" "$ID" >> "$LOG_FILE"
	[ -n "$ID" ] || MODE_VERIFY=partial
done

LTPO_STATE=$(sed -n '1p' "$CONFIG_DIR/ltpo_state" 2>/dev/null)
# Mode-ID parsing is diagnostic only.  A formatting change in dumpsys must not
# disable the already-loaded KO or prevent it from loading on the next boot.
printf '1\n' > "$CONFIG_DIR/enabled"
APPLY_RESULT=1
if [ -x "$REFRESH_APPLY" ]; then
	if "$REFRESH_APPLY" enforce >> "$LOG_FILE" 2>&1; then
		APPLY_RESULT=0
	else
		printf '%s initial_refresh_apply=failed\n' \
			"$(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
	fi
else
	printf '%s refresh_apply=missing\n' "$(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
fi

# The wake listener is required even when boot-time SurfaceFlinger refused one
# mode change.  It retries on the next screen-on event instead of leaving a
# stale guard pid with no event consumer.
if start_guard; then
	if [ "$APPLY_RESULT" -eq 0 ] && [ "$MODE_VERIFY" = ok ]; then
		write_state "modes_ready:global_control:ltpo_${LTPO_STATE:-unknown}:boot_${BOOT_PREP_STATE}"
	else
		write_state "ko_ready:guard_started:apply_${APPLY_RESULT}:modes_${MODE_VERIFY}:boot_${BOOT_PREP_STATE}"
		if [ "$APPLY_RESULT" -ne 0 ] && [ -x "$REFRESH_APPLY" ]; then
			(
				for DELAY in 2 4 6; do
					sleep "$DELAY"
					"$REFRESH_APPLY" replay >> "$LOG_FILE" 2>&1 && exit 0
				 done
			) &
		fi
	fi
else
	write_state "ko_ready:guard_start_failed:apply_${APPLY_RESULT}:boot_${BOOT_PREP_STATE}"
fi

supervise_guard
