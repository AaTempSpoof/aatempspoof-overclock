#!/system/bin/sh

# Profile files are verified after the module has been copied to MODPATH.
for profile_prop in "$MODPATH"/profiles/*/module.prop; do
    [ -f "$profile_prop" ] || continue
    legacy_id=""
    while IFS='=' read -r key value; do
        [ "$key" = id ] && legacy_id=$value
    done < "$profile_prop"
    [ -n "$legacy_id" ] || continue
    for root in /data/adb/modules /data/adb/modules_update; do
        [ -d "$root/$legacy_id" ] || continue
        [ -e "$root/$legacy_id/disable" ] && continue
        [ -e "$root/$legacy_id/remove" ] && continue
        abort "检测到仍启用的旧超频模块 $legacy_id；先卸载旧模块再刷入统一包"
    done
done

ui_print "AaTempSpoof 统一超频：设备与签名校验将在首次启动时执行"
