#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
mkdir -p "$CONFIG_DIR" 2>/dev/null || exit 0
printf '1\n' > "$CONFIG_DIR/enabled"
printf 'pending:verify\n' > "$CONFIG_DIR/state"
exec sh "$MODDIR/service_runtime.sh"
