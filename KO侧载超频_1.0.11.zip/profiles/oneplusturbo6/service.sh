#!/system/bin/sh
# 一加Turbo6 KO侧载超频 1.2.0 —— late_start 兜底
#
# post-fs-data.sh 有可能因为 msm_drm 未就绪、脚本被跳过或加载失败而没有生效。
# 这里在 sys.boot_completed=1 之后复查一次 applied：仍未生效就再 insmod 一次，
# 并把参数、dmesg 和模式表写入同一个 config/runtime.log。

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
LOG_FILE="$CONFIG_DIR/runtime.log"
STATE_FILE="$CONFIG_DIR/state"
KO="$MODDIR/bin/oneplus_turbo6_display_165_185_auto.ko"
KO_NAME=oneplus_turbo6_display_165_185_auto
DSI_MODES=/sys/class/drm/card0-DSI-1/modes

mkdir -p "$CONFIG_DIR" 2>/dev/null

log_line()
{
	printf '%s service: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE"
}

write_state()
{
	printf '%s\n' "$1" > "$STATE_FILE"
	log_line "state=$1"
}

read_param()
{
	cat "/sys/module/$KO_NAME/parameters/$1" 2>/dev/null
}

log_kernel()
{
	{
		printf '%s service: --- kernel log (oneplus_turbo6) ---\n' "$(date '+%Y-%m-%d %H:%M:%S')"
		dmesg 2>/dev/null | grep -i oneplus_turbo6 | tail -n 40
	} >> "$LOG_FILE"
}

TRIES=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ] && [ "$TRIES" -lt 150 ]; do
	sleep 2
	TRIES=$((TRIES + 1))
done
sleep 3

APPLIED=$(read_param applied)
CACHE=$(read_param cache_applied)
if [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; then
	log_line "boot_check applied=Y cache_applied=$CACHE final=$(read_param final_mode_count)"
	exit 0
fi

if grep -q "^${KO_NAME} " /proc/modules 2>/dev/null; then
	log_line "boot_check module_present applied=$APPLIED cache_applied=$CACHE"
	exit 0
fi

if [ ! -r "$KO" ]; then
	log_line "boot_check ko_missing path=$KO"
	exit 0
fi

if [ -x /system/bin/toybox ]; then
	/system/bin/toybox insmod "$KO" >> "$LOG_FILE" 2>&1
	RC=$?
else
	/system/bin/insmod "$KO" >> "$LOG_FILE" 2>&1
	RC=$?
fi

sleep 1
APPLIED=$(read_param applied)
CACHE=$(read_param cache_applied)
FINAL=$(read_param final_mode_count)
FAILURE=$(read_param failure_code)
log_line "boot_insmod rc=$RC applied=$APPLIED cache_applied=$CACHE final=$FINAL failure_code=$FAILURE clock_width=$(read_param mode_clock_width)"
log_kernel
if [ -r "$DSI_MODES" ]; then
	log_line "boot_modes=$(tr '\n' ',' < "$DSI_MODES")"
fi

if { [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; } &&
	{ [ "$CACHE" = Y ] || [ "$CACHE" = 1 ]; }; then
	write_state loaded
else
	write_state loaded_unverified
fi
exit 0
