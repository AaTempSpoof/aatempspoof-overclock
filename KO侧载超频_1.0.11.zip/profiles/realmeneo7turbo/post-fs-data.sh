#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
LOG_FILE="$CONFIG_DIR/runtime.log"
STATE_FILE="$CONFIG_DIR/state"
MODE_FILE="$CONFIG_DIR/mode"
KO="$MODDIR/bin/realme_neo7t_display_150_165_auto.ko"
KO_NAME=realme_neo7t_display_150_165_auto
DSI_MODES=/sys/class/drm/card0-DSI-1/modes

mkdir -p "$CONFIG_DIR" 2>/dev/null

log_line()
{
	printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE"
}

write_state()
{
	printf '%s\n' "$1" > "$STATE_FILE"
	log_line "state=$1"
}

read_param()
{
	cat "/sys/module/$KO_NAME/parameters/$1" 2>/dev/null
}

	# 上层（HWC / SurfaceFlinger）只在启动时读一次内核档位表并缓存。
	# KO 的注入发生在每次枚举（kretprobe 内同步补齐）；若
	# composer/HWC 服务在 KO 加载之前就已经启动并缓存了旧的 8 档，
	# 它不会自己重读；这里让它重新枚举一次：重启后重新初始化
	# 时正好命中已在位的 kretprobe，拿到补齐后的表。
	restart_composer()
	{
		for _svc in $(getprop 2>/dev/null | grep -o 'init[.]svc[.][A-Za-z0-9._-]*' | sed 's/^init[.]svc[.]//' | grep -i -E 'composer|hwcomposer'); do
			if [ "$(getprop "init.svc.$_svc" 2>/dev/null)" = "running" ]; then
				setprop ctl.restart "$_svc" 2>/dev/null
				log_line "restart_requested $_svc state=$(getprop "init.svc.$_svc" 2>/dev/null)"
			fi
		done
	}

log_modes()
{
	[ -r "$DSI_MODES" ] || { log_line "dsi_modes_unreadable"; return; }
	log_line "dsi_modes_total=$(grep -c . "$DSI_MODES") 1280x2800=$(grep -c '^1280x2800$' "$DSI_MODES") 1080x2362=$(grep -c '^1080x2362$' "$DSI_MODES")"
	log_line "dsi_modes=$(tr '\n' ',' < "$DSI_MODES")"
}

# 默认全功能（注入 + 接管回调）；若 config/mode 里写了 probe_only 则只注入不接管。
EXTRA=""
if [ -r "$MODE_FILE" ] && grep -q 'probe_only' "$MODE_FILE" 2>/dev/null; then
	EXTRA="probe_only=1"
fi

log_line "start module=$KO_NAME tiers=150/155/160/165 extra='$EXTRA'"

if [ ! -r "$KO" ]; then
	write_state ko_missing
	exit 0
fi

if [ -r "/sys/module/$KO_NAME/parameters/status" ]; then
	log_line "already_loaded $(read_param status | tr '\n' ' ')"
	write_state already_loaded
	restart_composer
	log_modes
	exit 0
fi

TRIES=0
while [ ! -d /sys/module/mediatek_drm ] && [ "$TRIES" -lt 30 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ ! -d /sys/module/mediatek_drm ]; then
	log_line "mediatek_drm_not_ready waited=${TRIES}s"
	write_state mediatek_drm_not_ready
	exit 0
fi

log_line "mediatek_drm_ready waited=${TRIES}s"

if grep -q "^${KO_NAME} " /proc/modules 2>/dev/null; then
	log_line "module_present_in_proc"
	write_state already_loaded
	restart_composer
	exit 0
fi

if [ -x /system/bin/toybox ]; then
	/system/bin/toybox insmod "$KO" $EXTRA >> "$LOG_FILE" 2>&1
	RC=$?
else
	/system/bin/insmod "$KO" $EXTRA >> "$LOG_FILE" 2>&1
	RC=$?
fi

if [ "$RC" -ne 0 ] && [ ! -r "/sys/module/$KO_NAME/parameters/status" ]; then
	log_line "insmod_failed rc=$RC"
	write_state insmod_failed
	exit 0
fi

TRIES=0
while [ ! -r "/sys/module/$KO_NAME/parameters/status" ] && [ "$TRIES" -lt 5 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

log_line "insmod_rc=$RC $(read_param status | tr '\n' ' ')"

APPLIED=$(read_param applied)
if [ "$APPLIED" = 1 ]; then
	write_state loaded
else
	write_state loaded_unverified
fi

restart_composer
log_modes
exit 0
