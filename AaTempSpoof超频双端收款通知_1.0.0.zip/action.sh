#!/system/bin/sh
BASE_DIR="${AATEMP_DUAL_LOGDIR:-/data/adb/aa-overclock-payment}"
case "${1:-status}" in
  status)
    echo "AaTempSpoof 双端收款通知"
    echo "AaTempSpoof 入口: $(sed -n '1p' "$BASE_DIR/aatempspoof/phone-url.txt" 2>/dev/null || echo '等待入口')"
    echo "独立超频入口: $(sed -n '1p' "$BASE_DIR/overclock/phone-url.txt" 2>/dev/null || echo '等待入口')"
    if [ -s "$BASE_DIR/overclock/phone-notification.key" ]; then
      echo "独立超频签名密钥: 已配对"
    else
      echo "独立超频签名密钥: 未配对"
    fi
    for side in aatempspoof overclock; do
      pid="$(sed -n '1p' "$BASE_DIR/$side/sponsor-listener.pid" 2>/dev/null)"
      if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then echo "$side listener: 运行中 (PID $pid)"; else echo "$side listener: 未运行"; fi
    done
    ;;
  once) sh "${0%/*}/service.sh" --once ;;
  stop)
    for side in aatempspoof overclock; do pid="$(sed -n '1p' "$BASE_DIR/$side/sponsor-listener.pid" 2>/dev/null)"; [ -n "$pid" ] && kill "$pid" 2>/dev/null || true; done
    ;;
  *) echo "用法: $0 {status|once|stop}"; exit 2 ;;
esac
