#!/system/bin/sh
# 一加Turbo6 KO侧载超频 1.2.0
#
# 1.2.0 说明：
#  * 用新采集包（oc_adapt_PLU110_20260927-112501）重建；面板/时序事实不变，
#    blob/msm_drm.ko 与上一版逐字节一致。档位收敛为「原生 6 档 + 仅追加 180/185」共 8 档。
#  * 1.0.0 的真机日志是 insmod "Protocol error"（模块 __init 探测失败返回 -EPROTO）；
#    1.1.0 加了 Hz/kHz 双单位探测但真机仍不显示档位（2026-09-27 采集时 /proc/modules 与
#    /data/adb/modules 都没有该模块）。1.2.0 追加「4/8 字节时钟宽度」探测：真机记录里
#    DSI 时钟字段是 u32，1.1.0 只按 u64 读会得到 Hz|(kHz<<32)，探测必然失败。
#  * 加载前清理 bin/ 里的旧 KO 残留；脚本必须保持 LF 行尾（不要用 Windows 编辑器另存为 CRLF）。
#  * 新增 service.sh 兜底：开机完成后复查 applied，未生效则再 insmod 一次，失败留 dmesg。

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
LOG_FILE="$CONFIG_DIR/runtime.log"
STATE_FILE="$CONFIG_DIR/state"
KO="$MODDIR/bin/oneplus_turbo6_display_165_185_auto.ko"
KO_NAME=oneplus_turbo6_display_165_185_auto
MODULE_VERSION=1.2.0
DSI_MODES=/sys/class/drm/card0-DSI-1/modes

mkdir -p "$CONFIG_DIR" 2>/dev/null

log_line()
{
	printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE"
}

write_state()
{
	printf '%s\n' "$1" > "$STATE_FILE"
	log_line "state=$1"
}

read_param()
{
	cat "/sys/module/$KO_NAME/parameters/$1" 2>/dev/null
}

log_kernel()
{
	{
		printf '%s --- kernel log (oneplus_turbo6) ---\n' "$(date '+%Y-%m-%d %H:%M:%S')"
		dmesg 2>/dev/null | grep -i oneplus_turbo6 | tail -n 40
	} >> "$LOG_FILE"
}

log_modes()
{
	[ -r "$DSI_MODES" ] || { log_line "dsi_modes_unreadable"; return; }
	COUNT=$(grep -c '' "$DSI_MODES" 2>/dev/null)
	if grep -q 'x185vid' "$DSI_MODES" 2>/dev/null; then
		log_line "dsi_modes_has_185=yes count=$COUNT modes=$(tr '\n' ',' < "$DSI_MODES")"
	elif grep -q 'x165vid' "$DSI_MODES" 2>/dev/null; then
		log_line "dsi_modes_has_185=no dsi_modes_has_165=yes count=$COUNT modes=$(tr '\n' ',' < "$DSI_MODES")"
	else
		log_line "dsi_modes_has_185=no count=$COUNT modes=$(tr '\n' ',' < "$DSI_MODES")"
	fi
}

# 升级/降级残留：bin/ 里除本版本 KO 以外的 *165_*.ko 一律清掉，避免加载到旧模块
for stale in "$MODDIR"/bin/oneplus_turbo6_display_*.ko; do
	[ -e "$stale" ] || continue
	[ "$stale" = "$KO" ] && continue
	rm -f "$stale" 2>/dev/null && log_line "removed_stale_ko=$(basename "$stale")"
done

log_line "start module=$KO_NAME tiers=180/185 max_refresh=185 version=$MODULE_VERSION"

if [ ! -r "$KO" ]; then
	write_state ko_missing
	log_line "ko_unreadable path=$KO"
	exit 0
fi

if [ -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	APPLIED=$(read_param applied)
	CACHE=$(read_param cache_applied)
	log_line "already_loaded applied=$APPLIED cache_applied=$CACHE"
	if [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; then
		write_state already_loaded
	else
		write_state already_loaded_unverified
	fi
	log_modes
	exit 0
fi

TRIES=0
while [ ! -d /sys/module/msm_drm ] && [ "$TRIES" -lt 30 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ ! -d /sys/module/msm_drm ]; then
	log_line "msm_drm_not_ready waited=${TRIES}s"
	write_state msm_drm_not_ready
	exit 0
fi

log_line "msm_drm_ready waited=${TRIES}s"

if grep -q "^${KO_NAME} " /proc/modules 2>/dev/null; then
	log_line "module_present_in_proc"
	write_state already_loaded
	exit 0
fi

if [ -x /system/bin/toybox ]; then
	/system/bin/toybox insmod "$KO" >> "$LOG_FILE" 2>&1
	RC=$?
else
	/system/bin/insmod "$KO" >> "$LOG_FILE" 2>&1
	RC=$?
fi

if [ "$RC" -ne 0 ] && [ ! -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	log_line "insmod_failed rc=$RC"
	log_kernel
	write_state insmod_failed
	exit 0
fi

TRIES=0
while [ ! -r "/sys/module/$KO_NAME/parameters/applied" ] && [ "$TRIES" -lt 5 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

APPLIED=$(read_param applied)
CACHE=$(read_param cache_applied)
MODE_COUNT=$(read_param mode_count_after)
NATIVE=$(read_param native_mode_count)
TARGET=$(read_param target_mode_count)
FINAL=$(read_param final_mode_count)
FAILURE=$(read_param failure_code)
CLOCK_FIELD=$(read_param mode_clock_field)
CLOCK_UNIT=$(read_param mode_clock_unit)
CLOCK_WIDTH=$(read_param mode_clock_width)
PRIV_SHARED=$(read_param priv_shared)
log_line "insmod_rc=$RC applied=$APPLIED cache_applied=$CACHE mode_count_after=$MODE_COUNT native=$NATIVE target=$TARGET final=$FINAL failure_code=$FAILURE clock_field=$CLOCK_FIELD clock_unit=$CLOCK_UNIT clock_width=$CLOCK_WIDTH priv_shared=$PRIV_SHARED"

if { [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; } &&
	{ [ "$CACHE" = Y ] || [ "$CACHE" = 1 ]; }; then
	write_state loaded
else
	write_state loaded_unverified
fi

log_kernel
log_modes
exit 0
