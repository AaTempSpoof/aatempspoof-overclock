#!/system/bin/sh

MODULE_DIR=${0%/*}
CONFIG_DIR="$MODULE_DIR/config"
SELECTED_PROFILE=$(cat "$CONFIG_DIR/selected_profile" 2>/dev/null | tr -d '\r\n ')
PROFILE_DIR="$MODULE_DIR/profiles/$SELECTED_PROFILE"
if [ -x "$PROFILE_DIR/unified-uninstall.sh" ]; then
    sh "$PROFILE_DIR/unified-uninstall.sh" "$PROFILE_DIR" "$CONFIG_DIR/legacy-disabled.list" || true
elif [ -x "$PROFILE_DIR/uninstall.sh" ]; then
    sh "$PROFILE_DIR/uninstall.sh" || true
fi
MIGRATION_FILE="$CONFIG_DIR/legacy-disabled.list"
if [ -r "$MIGRATION_FILE" ]; then
    while IFS= read -r module; do
        [ -n "$module" ] || continue
        [ -d "$module" ] && rm -f "$module/disable" 2>/dev/null || true
    done < "$MIGRATION_FILE"
fi
rm -f "$MIGRATION_FILE" 2>/dev/null || true
