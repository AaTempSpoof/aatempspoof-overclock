#!/system/bin/sh

# Profile files are verified after the module has been copied to MODPATH.
mkdir -p "$MODPATH/config" 2>/dev/null || abort "无法创建统一模块配置目录"
for executable in "$MODPATH/bin/oc_guard.sh" "$MODPATH/bin/openssl" "$MODPATH/bin/openssl.real" "$MODPATH/post-fs-data.sh" "$MODPATH/service.sh" "$MODPATH/uninstall.sh"; do
    [ -f "$executable" ] && set_perm "$executable" 0 0 0755
done
PROFILE_MIGRATION_FILE="$MODPATH/config/legacy-disabled.list"
rollback_migration() {
    if [ -r "$PROFILE_MIGRATION_FILE" ]; then
        while IFS= read -r old_module; do
            [ -n "$old_module" ] || continue
            [ -d "$old_module" ] && rm -f "$old_module/disable" 2>/dev/null || true
        done < "$PROFILE_MIGRATION_FILE"
    fi
    rm -f "$PROFILE_MIGRATION_FILE" 2>/dev/null || true
}
legacy_ids=$(sed -n 's/^legacy_module_ids=//p' "$MODPATH/module.prop" | head -n 1 | tr -d '\r\n ')
[ -n "$legacy_ids" ] || abort "统一包缺少旧模块迁移清单"
remaining=$legacy_ids
while [ -n "$remaining" ]; do
    legacy_id=${remaining%%,*}
    if [ "$remaining" = "$legacy_id" ]; then remaining=""; else remaining=${remaining#*,}; fi
    [ -n "$legacy_id" ] || continue
    for root in /data/adb/modules /data/adb/modules_update; do
        old_module="$root/$legacy_id"
        [ -d "$old_module" ] || continue
        [ "$old_module" = "$MODPATH" ] && continue
        [ -e "$old_module/disable" ] && continue
        [ -e "$old_module/remove" ] && continue
        if touch "$old_module/disable" 2>/dev/null; then
            printf '%s\n' "$old_module" >> "$PROFILE_MIGRATION_FILE"
            ui_print "- 已停用旧超频模块 $legacy_id"
        else
            rollback_migration
            abort "无法停用旧超频模块 $legacy_id"
        fi
    done
done

read_prop() {
    key=$1
    getprop "$key" 2>/dev/null | tr -d '\r\n' | cut -c 1-96
}

device_code=$(read_prop ro.product.device)
device_model=$(read_prop ro.product.model)
[ -n "$device_model" ] || device_model=$(read_prop ro.product.vendor.model)
[ -n "$device_model" ] || device_model="未知机型"
[ -n "$device_code" ] || device_code="未知代号"
kernel_release=$(uname -r 2>/dev/null | tr -d '\r\n' | cut -c 1-160)
[ -n "$kernel_release" ] || kernel_release="未知内核"
detected_profile=""
detected_name=""
if [ -r "$MODPATH/overclock-manifest.txt" ]; then
    while IFS= read -r line; do
        case "$line" in profile_id=*) ;; *) continue ;; esac
        codes=$(printf '%s\n' "$line" | sed -n 's/.*device_code=\([^ ]*\).*/\1/p')
        case ",${codes}," in
            *,"$device_code",*)
                detected_profile=$(printf '%s\n' "$line" | sed -n 's/.*profile_id=\([^ ]*\).*/\1/p')
                detected_name=$(printf '%s\n' "$line" | sed -n 's/.*model_name=\([^ ]*\).*/\1/p')
                break
                ;;
        esac
    done < "$MODPATH/overclock-manifest.txt"
fi
ui_print "KO侧载超频：正在自动识别设备"
ui_print "- 机型：$device_model ($device_code)"
detected_label=$(printf '%s' "$detected_name" | tr '_' ' ')
[ -n "$detected_name" ] && ui_print "- 清单匹配：$detected_label [$detected_profile]"
[ -z "$detected_name" ] && ui_print "- 清单匹配：等待解包后进行精确机型匹配"
ui_print "- 内核：$kernel_release"
ui_print "- 解包后校验主板 ID、SoC、内核、驱动、文件 SHA-256 与授权签名"
if [ -n "$detected_label" ] && [ -w "$MODPATH/module.prop" ]; then
    escaped_label=$(printf '%s' "$detected_label" | tr -d '\r\n' | sed 's/[\/&]/ /g')
    [ -n "$escaped_label" ] && sed -i "s/^description=.*/description=$escaped_label KO侧载超频：已识别机型，启动前继续校验授权/" "$MODPATH/module.prop" 2>/dev/null || true
fi
