#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
REFRESH_GUARD="$MODDIR/bin/refresh_guard"
GUARD_PID_FILE="$CONFIG_DIR/guard.pid"

printf '0\n' > "$CONFIG_DIR/enabled" 2>/dev/null

guard_process_matches()
{
	PID=$1
	case "$PID" in
		''|*[!0-9]*) return 1 ;;
	esac
	kill -0 "$PID" 2>/dev/null || return 1
	CMDLINE=$(tr '\0' ' ' < "/proc/$PID/cmdline" 2>/dev/null) || return 1
	case "$CMDLINE" in
		"$REFRESH_GUARD --module $MODDIR "*) return 0 ;;
		*) return 1 ;;
	esac
}

PID=$(sed -n '1p' "$GUARD_PID_FILE" 2>/dev/null | awk '{print $1}')
if guard_process_matches "$PID"; then
	kill -TERM "$PID" 2>/dev/null || true
	WAIT_TRY=0
	while [ "$WAIT_TRY" -lt 50 ] && guard_process_matches "$PID"; do
		sleep 0.1
		WAIT_TRY=$((WAIT_TRY + 1))
	done
	if guard_process_matches "$PID"; then
		kill -KILL "$PID" 2>/dev/null || true
		WAIT_TRY=0
		while [ "$WAIT_TRY" -lt 20 ] && guard_process_matches "$PID"; do
			sleep 0.1
			WAIT_TRY=$((WAIT_TRY + 1))
		done
	fi
fi
guard_process_matches "$PID" || rm -f "$GUARD_PID_FILE" 2>/dev/null

[ -x "$MODDIR/bin/refresh_apply.sh" ] &&
	"$MODDIR/bin/refresh_apply.sh" restore >/dev/null 2>&1 || true
[ -x "$MODDIR/bin/ltpo_control.sh" ] &&
	"$MODDIR/bin/ltpo_control.sh" restore
/system/bin/pm uninstall com.aatempspoof.scenerefresh >/dev/null 2>&1 || true
for BRIDGE_DIR in \
	/data/user/0/com.oplus.games/files/aatempspoof_refresh_bridge \
	/data/user_de/0/com.android.settings/files/aatempspoof_refresh_bridge \
	/data/user/0/com.android.settings/files/aatempspoof_refresh_bridge; do
	rm -f "$BRIDGE_DIR/request" "$BRIDGE_DIR/request.tmp" \
		"$BRIDGE_DIR/ack" "$BRIDGE_DIR/ack.tmp" \
		"$BRIDGE_DIR/app_rates" "$BRIDGE_DIR/app_rates.tmp" 2>/dev/null
	rmdir "$BRIDGE_DIR" 2>/dev/null || true
done
/system/bin/settings delete global oneplus15_display_game_active >/dev/null 2>&1 || true
/system/bin/settings delete global oneplus15_display_app_active >/dev/null 2>&1 || true
/system/bin/settings delete global oneplus15_display_app_rates >/dev/null 2>&1 || true
/system/bin/settings delete global oneplus15_display_global_rate >/dev/null 2>&1 || true
echo "全局刷新率和 LTPO 配置已恢复，模块移除后请重启以恢复原厂内存模式列表"
