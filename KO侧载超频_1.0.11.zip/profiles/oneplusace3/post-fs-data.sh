#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
LOG_FILE="$CONFIG_DIR/runtime.log"
STATE_FILE="$CONFIG_DIR/state"
KO="$MODDIR/bin/oneplus_ace3_display_120_144_auto.ko"
KO_NAME=oneplus_ace3_display_120_144_auto
TEMPLATE_FPS=120
DSI_MODES=/sys/class/drm/card0-DSI-1/modes

mkdir -p "$CONFIG_DIR" 2>/dev/null

log_line()
{
	printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE"
}

write_state()
{
	printf '%s\n' "$1" > "$STATE_FILE"
	log_line "state=$1"
}

read_param()
{
	cat "/sys/module/$KO_NAME/parameters/$1" 2>/dev/null
}

log_modes()
{
	[ -r "$DSI_MODES" ] || { log_line "dsi_modes_unreadable"; return; }
	COUNT=$(grep -c '' "$DSI_MODES" 2>/dev/null)
	if grep -q 'x144cmd' "$DSI_MODES" 2>/dev/null; then
		log_line "dsi_modes_has_144=yes count=$COUNT modes=$(tr '\n' ',' < "$DSI_MODES")"
	else
		log_line "dsi_modes_has_144=no count=$COUNT modes=$(tr '\n' ',' < "$DSI_MODES")"
	fi
}

log_line "start module=$KO_NAME tiers=130/131/140/141/144 max_refresh=144 template=$TEMPLATE_FPS"

if [ ! -r "$KO" ]; then
	write_state ko_missing
	exit 0
fi

if [ -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	APPLIED=$(read_param applied)
	CACHE=$(read_param cache_applied)
	log_line "already_loaded applied=$APPLIED cache_applied=$CACHE"
	if [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; then
		write_state already_loaded
	else
		write_state already_loaded_unverified
	fi
	log_modes
	exit 0
fi

TRIES=0
while [ ! -d /sys/module/msm_drm ] && [ "$TRIES" -lt 30 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ ! -d /sys/module/msm_drm ]; then
	log_line "msm_drm_not_ready waited=${TRIES}s"
	write_state msm_drm_not_ready
	exit 0
fi

log_line "msm_drm_ready waited=${TRIES}s"

if grep -q "^${KO_NAME} " /proc/modules 2>/dev/null; then
	log_line "module_present_in_proc"
	write_state already_loaded
	exit 0
fi

if [ -x /system/bin/toybox ]; then
	/system/bin/toybox insmod "$KO" >> "$LOG_FILE" 2>&1
	RC=$?
else
	/system/bin/insmod "$KO" >> "$LOG_FILE" 2>&1
	RC=$?
fi

if [ "$RC" -ne 0 ] && [ ! -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	log_line "insmod_failed rc=$RC"
	write_state insmod_failed
	exit 0
fi

TRIES=0
while [ ! -r "/sys/module/$KO_NAME/parameters/applied" ] && [ "$TRIES" -lt 5 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

APPLIED=$(read_param applied)
CACHE=$(read_param cache_applied)
BEFORE=$(read_param mode_count_before)
AFTER=$(read_param mode_count_after)
CLOCK=$(read_param target_clock_hz)
SOURCE_IDX=$(read_param source_mode_index)
SOURCE_CLK=$(read_param source_clock_hz)
FAILURE=$(read_param failure_code)
EXTRAS=$(read_param priv_extras_ok)
EXTRAS_FAIL=$(read_param priv_extras_fail)
SRC_MDP=$(read_param src_mdp_transfer)
SRC_DYN0=$(read_param src_dyn0)
TARGET_MDP=$(read_param target_mdp)
log_line "insmod_rc=$RC applied=$APPLIED cache_applied=$CACHE mode_count_before=$BEFORE mode_count_after=$AFTER source_mode_index=$SOURCE_IDX source_clock_hz=$SOURCE_CLK target_clock_hz=$CLOCK failure_code=$FAILURE priv_extras_ok=$EXTRAS priv_extras_fail=$EXTRAS_FAIL src_mdp_transfer=$SRC_MDP src_dyn0=$SRC_DYN0 target_mdp=$TARGET_MDP"

if { [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; } &&
	{ [ "$CACHE" = Y ] || [ "$CACHE" = 1 ]; }; then
	write_state loaded
else
	write_state loaded_unverified
fi

log_modes
exit 0
