#!/system/bin/sh
MODDIR="${0%/*}"
BASE_DIR="${AATEMP_DUAL_LOGDIR:-/data/adb/aa-overclock-payment}"
AAT_LOGDIR="$BASE_DIR/aatempspoof"
OC_LOGDIR="$BASE_DIR/overclock"
LISTENER="$MODDIR/bin/sponsor-listener"
CURL="${AATEMP_PAYMENT_CURL:-/system/bin/curl}"
AAT_CLOUD_ENTRY="${AATEMP_AAT_CLOUD_ENTRY:-https://aatempspoof.github.io/aatempspoof-cloud/cloud.txt}"
OC_CLOUD_ENTRY="${AATEMP_OC_CLOUD_ENTRY:-https://aatempspoof.github.io/aatempspoof-overclock/cloud.txt}"
AM="${AATEMP_PAYMENT_AM:-/system/bin/am}"
CMD="${AATEMP_PAYMENT_CMD:-/system/bin/cmd}"
PKG="com.aatempspoof.payment"

mkdir -p "$AAT_LOGDIR" "$OC_LOGDIR" 2>/dev/null || true
chmod 0700 "$BASE_DIR" "$AAT_LOGDIR" "$OC_LOGDIR" 2>/dev/null || true
log() { printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$BASE_DIR/notification-service.log"; chmod 0600 "$BASE_DIR/notification-service.log" 2>/dev/null || true; }
refresh_url() {
  out_dir=$1; entry_url=$2; [ -x "$CURL" ] || return 1
  tmp="$out_dir/cloud.txt.$$"
  "$CURL" --noproxy '*' -fsS --connect-timeout 8 --max-time 20 "$entry_url?ts=$(date +%s)" -o "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
  api="$(sed -n 's/^api=//p' "$tmp" | head -n 1 | tr -d '\r' | sed 's:/*$::')"; rm -f "$tmp"
  case "$api" in https://*.trycloudflare.com) printf '%s\n' "$api/sponsor/phone-notification" > "$out_dir/phone-url.txt"; chmod 0600 "$out_dir/phone-url.txt"; return 0 ;; esac
  return 1
}
start_one() {
  logdir=$1; require_key=${2:-0}; [ -x "$LISTENER" ] || return 1
  if [ "$require_key" = 1 ]; then
    key_file="$logdir/phone-notification.key"
    key_bytes="$(wc -c < "$key_file" 2>/dev/null | tr -d '[:space:]')"
    case "$key_bytes" in
      32|64|65|66) ;;
      *) log "独立超频 listener 等待 phone-notification.key（需要 32 字节原始密钥或 64 位 hex）"; return 1 ;;
    esac
    if [ "$key_bytes" != 32 ]; then
      key_text="$(sed 's/\r$//' "$key_file" 2>/dev/null)"
      [ "${#key_text}" -eq 64 ] || { log "独立超频 listener 的 phone-notification.key 格式无效"; return 1; }
      case "$key_text" in *[!0-9a-fA-F]*) log "独立超频 listener 的 phone-notification.key 格式无效"; return 1 ;; esac
    fi
    chmod 0600 "$key_file" 2>/dev/null || true
  fi
  pidfile="$logdir/sponsor-listener.pid"; old="$(sed -n '1p' "$pidfile" 2>/dev/null)"
  if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then return 0; fi
  if [ "$require_key" = 1 ]; then
    AATS_REQUIRE_HMAC=1 nohup "$LISTENER" --daemon "$MODDIR" "$logdir" </dev/null >> "$logdir/sponsor-listener.log" 2>&1 &
  else
    nohup "$LISTENER" --daemon "$MODDIR" "$logdir" </dev/null >> "$logdir/sponsor-listener.log" 2>&1 &
  fi
  printf '%s\n' "$!" > "$pidfile"; chmod 0600 "$pidfile" "$logdir/sponsor-listener.log" 2>/dev/null || true
}
if [ "${1:-}" = "--once" ]; then
  refresh_url "$AAT_LOGDIR" "$AAT_CLOUD_ENTRY" || log "AaTempSpoof 入口刷新失败"; refresh_url "$OC_LOGDIR" "$OC_CLOUD_ENTRY" || log "独立超频入口刷新失败"; start_one "$AAT_LOGDIR" 0; start_one "$OC_LOGDIR" 1; exit 0
fi
printf '%s\n' "$$" > "$BASE_DIR/notification-service.pid"; trap 'rm -f "$BASE_DIR/notification-service.pid"; exit 0' HUP INT TERM EXIT
while true; do refresh_url "$AAT_LOGDIR" "$AAT_CLOUD_ENTRY" || true; refresh_url "$OC_LOGDIR" "$OC_CLOUD_ENTRY" || true; start_one "$AAT_LOGDIR" 0; start_one "$OC_LOGDIR" 1; [ -x "$AM" ] && "$AM" set-standby-bucket "$PKG" active >/dev/null 2>&1 || true; [ -x "$CMD" ] && "$CMD" deviceidle whitelist "+$PKG" >/dev/null 2>&1 || true; sleep 30; done
