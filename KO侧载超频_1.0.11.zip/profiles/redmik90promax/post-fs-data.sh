#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
LOG_FILE="$CONFIG_DIR/runtime.log"
STATE_FILE="$CONFIG_DIR/state"
KO="$MODDIR/bin/myron_display_120_144_165_auto.ko"
KO_NAME=myron_oc_display

mkdir -p "$CONFIG_DIR" 2>/dev/null

log_line()
{
	printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE"
}

write_state()
{
	printf '%s\n' "$1" > "$STATE_FILE"
	log_line "state=$1"
}

read_param()
{
	cat "/sys/module/$KO_NAME/parameters/$1" 2>/dev/null
}

find_dsi_node()
{
	for p in /sys/class/drm/card*-DSI-*/status; do
		[ -e "$p" ] && { printf '%s\n' "$p"; return 0; }
	done
	return 1
}

log_line "start module=$KO_NAME max_refresh=165"

if [ ! -r "$KO" ]; then
	write_state ko_missing
	exit 0
fi

if [ -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	APPLIED=$(read_param applied)
	log_line "already_loaded applied=$APPLIED stage=$(read_param stage)"
	if [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; then
		write_state already_loaded
	else
		write_state already_loaded_unverified
	fi
	exit 0
fi

TRIES=0
while [ ! -d /sys/module/msm_drm ] && [ "$TRIES" -lt 30 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ ! -d /sys/module/msm_drm ]; then
	log_line "msm_drm_not_ready waited=${TRIES}s"
	write_state msm_drm_not_ready
	exit 0
fi

log_line "msm_drm_ready waited=${TRIES}s"

if grep -q "^${KO_NAME} " /proc/modules 2>/dev/null; then
	log_line "module_present_in_proc"
	write_state already_loaded
	exit 0
fi

if [ -x /system/bin/toybox ]; then
	/system/bin/toybox insmod "$KO" probe_only=0 scale_bitclk=1 fix_transfer_time=1 fix_pixel_clock=1 dump_always=0 priv_dump_size=0 >> "$LOG_FILE" 2>&1
	RC=$?
else
	/system/bin/insmod "$KO" probe_only=0 scale_bitclk=1 fix_transfer_time=1 fix_pixel_clock=1 dump_always=0 priv_dump_size=0 >> "$LOG_FILE" 2>&1
	RC=$?
fi

if [ "$RC" -ne 0 ] && [ ! -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	log_line "insmod_failed rc=$RC"
	write_state insmod_failed
	exit 0
fi

# 面板对象的捕获挂在一次 display 探测上；探测同时用于刷新 connector 的模式列表，
# 必须在 SurfaceFlinger / 合成器启动前完成，系统才能枚举到 144/165。
TRIES=0
DSI_NODE=""
while [ "$TRIES" -lt 10 ]; do
	DSI_NODE=$(find_dsi_node) && break
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ -n "$DSI_NODE" ]; then
	echo detect > "$DSI_NODE" 2>>"$LOG_FILE"
	log_line "detect sent node=$DSI_NODE waited=${TRIES}s"
else
	log_line "dsi_node_missing waited=${TRIES}s"
fi

TRIES=0
while [ "$TRIES" -lt 15 ]; do
	APPLIED=$(read_param applied)
	{ [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; } && break
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ -n "$DSI_NODE" ]; then
	echo detect > "$DSI_NODE" 2>>"$LOG_FILE"
fi

APPLIED=$(read_param applied)
STAGE=$(read_param stage)
COUNT_BEFORE=$(read_param count_before)
COUNT_AFTER=$(read_param count_after)
FAILURE=$(read_param failure_code)
VERIFY=$(read_param verify_step)
TRANSFER_ERR=$(read_param transfer_error)
DSI_BUDGET=$(read_param src_dsi_transfer)
PCLK=$(read_param src_pixel_clock)
PCLK_OFF=$(read_param pixel_clock_offset_dbg)
PCLK_CANDS=$(read_param pclk_cands)
log_line "insmod_rc=$RC applied=$APPLIED stage=$STAGE count=$COUNT_BEFORE->$COUNT_AFTER failure_code=$FAILURE verify_step=$VERIFY transfer_error=$TRANSFER_ERR dsi_budget=$DSI_BUDGET pclk=$PCLK@$PCLK_OFF cands=$PCLK_CANDS waited=${TRIES}s"

if [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; then
	write_state loaded
else
	write_state loaded_unverified
fi

exit 0
