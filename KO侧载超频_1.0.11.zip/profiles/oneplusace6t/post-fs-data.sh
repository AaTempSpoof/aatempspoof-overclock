#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
LOG_FILE="$CONFIG_DIR/runtime.log"
STATE_FILE="$CONFIG_DIR/state"
KO="$MODDIR/bin/oneplus_ace6t_display_165_200_auto.ko"
KO_NAME=oneplus_ace6t_display_165_200_auto
DSI_MODES=/sys/class/drm/card0-DSI-1/modes

mkdir -p "$CONFIG_DIR" 2>/dev/null

log_line()
{
	printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE"
}

write_state()
{
	printf '%s\n' "$1" > "$STATE_FILE"
	log_line "state=$1"
}

read_param()
{
	cat "/sys/module/$KO_NAME/parameters/$1" 2>/dev/null
}

log_modes()
{
	[ -r "$DSI_MODES" ] || { log_line "dsi_modes_unreadable"; return; }
	COUNT=$(grep -c '' "$DSI_MODES" 2>/dev/null)
	if grep -q 'x200cmd' "$DSI_MODES" 2>/dev/null; then
		log_line "dsi_modes_has_200=yes count=$COUNT modes=$(tr '\n' ',' < "$DSI_MODES")"
	else
		log_line "dsi_modes_has_200=no count=$COUNT modes=$(tr '\n' ',' < "$DSI_MODES")"
	fi
}

log_line "start module=$KO_NAME tiers=180/185/190/195/200 max_refresh=200"

if [ ! -r "$KO" ]; then
	write_state ko_missing
	exit 0
fi

if [ -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	APPLIED=$(read_param applied)
	CACHE=$(read_param cache_applied)
	log_line "already_loaded applied=$APPLIED cache_applied=$CACHE"
	if [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; then
		write_state already_loaded
	else
		write_state already_loaded_unverified
	fi
	log_modes
	exit 0
fi

TRIES=0
while [ ! -d /sys/module/msm_drm ] && [ "$TRIES" -lt 30 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ ! -d /sys/module/msm_drm ]; then
	log_line "msm_drm_not_ready waited=${TRIES}s"
	write_state msm_drm_not_ready
	exit 0
fi

log_line "msm_drm_ready waited=${TRIES}s"

if grep -q "^${KO_NAME} " /proc/modules 2>/dev/null; then
	log_line "module_present_in_proc"
	write_state already_loaded
	exit 0
fi

if [ -x /system/bin/toybox ]; then
	/system/bin/toybox insmod "$KO" >> "$LOG_FILE" 2>&1
	RC=$?
else
	/system/bin/insmod "$KO" >> "$LOG_FILE" 2>&1
	RC=$?
fi

if [ "$RC" -ne 0 ] && [ ! -r "/sys/module/$KO_NAME/parameters/applied" ]; then
	log_line "insmod_failed rc=$RC"
	write_state insmod_failed
	exit 0
fi

TRIES=0
while [ ! -r "/sys/module/$KO_NAME/parameters/applied" ] && [ "$TRIES" -lt 5 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

APPLIED=$(read_param applied)
CACHE=$(read_param cache_applied)
BEFORE=$(read_param mode_count_before)
AFTER=$(read_param mode_count_after)
CLOCK=$(read_param target_clock_hz)
FAILURE=$(read_param failure_code)
log_line "insmod_rc=$RC applied=$APPLIED cache_applied=$CACHE mode_count_before=$BEFORE mode_count_after=$AFTER target_clock_hz=$CLOCK failure_code=$FAILURE"

if { [ "$APPLIED" = Y ] || [ "$APPLIED" = 1 ]; } &&
	{ [ "$CACHE" = Y ] || [ "$CACHE" = 1 ]; }; then
	write_state loaded
else
	write_state loaded_unverified
fi

log_modes
exit 0
