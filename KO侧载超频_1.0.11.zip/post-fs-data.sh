#!/system/bin/sh

MODDIR=${0%/*}
if [ ! -s "$MODDIR/config/selected_profile" ] && ! sh "$MODDIR/bin/oc_guard.sh" install; then
    # Keep this module enabled so service.sh can retry after clock/network setup.
    # The guard remains fail-closed and does not load a profile on failure.
    exit 0
fi
sh "$MODDIR/bin/oc_guard.sh" boot
