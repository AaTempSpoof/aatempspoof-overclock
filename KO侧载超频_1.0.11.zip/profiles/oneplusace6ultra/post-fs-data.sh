#!/system/bin/sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/config"
LOG_FILE="$CONFIG_DIR/runtime.log"
STATE_FILE="$CONFIG_DIR/state"
AUTO_FILE="$CONFIG_DIR/auto_enable"
KO="$MODDIR/bin/PMB110_180_195_Mode.ko"
KO_NAME=pmb110_180_195_mode
DSI_MODES=/sys/class/drm/card0-DSI-1/modes

mkdir -p "$CONFIG_DIR" 2>/dev/null

log_line()
{
	printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE"
}

write_state()
{
	printf '%s\n' "$1" > "$STATE_FILE"
	log_line "state=$1"
}

read_param()
{
	cat "/sys/module/$KO_NAME/parameters/$1" 2>/dev/null
}

count_modes()
{
	MODE_LINES=0
	while IFS= read -r MODE_LINE || [ -n "$MODE_LINE" ]; do
		MODE_LINES=$((MODE_LINES + 1))
	done < "$DSI_MODES" 2>/dev/null
	printf '%s\n' "$MODE_LINES"
}

log_modes()
{
	if [ ! -r "$DSI_MODES" ]; then
		log_line "dsi_modes_unreadable"
		return
	fi
	log_line "dsi_modes_count=$(count_modes) modes=$(tr '\n' ',' < "$DSI_MODES")"
}

if [ ! -e "$AUTO_FILE" ]; then
	printf '1\n' > "$AUTO_FILE" 2>/dev/null
fi

log_line "start module=$KO_NAME tiers=180/185/190/195 native=12 total=20"

if [ ! -r "$KO" ]; then
	write_state ko_missing
	exit 0
fi

if [ -r "/sys/module/$KO_NAME/parameters/status" ]; then
	log_line "already_loaded status=$(read_param status)"
	write_state already_loaded
	exit 0
fi

TRIES=0
while [ ! -r "$DSI_MODES" ] && [ "$TRIES" -lt 30 ]; do
	sleep 1
	TRIES=$((TRIES + 1))
done

if [ ! -r "$DSI_MODES" ]; then
	log_line "dsi_not_ready waited=${TRIES}s"
	write_state dsi_not_ready
	exit 0
fi

log_line "dsi_ready waited=${TRIES}s modes_before=$(count_modes)"

if grep -q "^${KO_NAME} " /proc/modules 2>/dev/null; then
	log_line "module_present_in_proc"
	write_state already_loaded
	exit 0
fi

insmod_ko()
{
	if [ -x /system/bin/toybox ]; then
		/system/bin/toybox insmod "$KO" boot_mode="$1" >> "$LOG_FILE" 2>&1
	else
		/system/bin/insmod "$KO" boot_mode="$1" >> "$LOG_FILE" 2>&1
	fi
}

REQUESTED_BOOT_MODE=1
insmod_ko "$REQUESTED_BOOT_MODE"
RC=$?
if [ "$RC" -ne 0 ] && [ ! -r "/sys/module/$KO_NAME/parameters/status" ]; then
	log_line "insmod_boot_mode_1_failed rc=$RC retry_boot_mode_0"
	REQUESTED_BOOT_MODE=0
	insmod_ko "$REQUESTED_BOOT_MODE"
	RC=$?
fi

if [ "$RC" -ne 0 ] && [ ! -r "/sys/module/$KO_NAME/parameters/status" ]; then
	log_line "insmod_failed rc=$RC"
	write_state insmod_failed
	exit 0
fi

BOOT_MODE_RAW=$(read_param boot_mode)
[ -n "$BOOT_MODE_RAW" ] || BOOT_MODE_RAW=0

case "$BOOT_MODE_RAW" in
1|Y|y|true|on) BOOT_MODE=1 ;;
*) BOOT_MODE=0 ;;
esac

log_line "insmod_rc=$RC requested_boot_mode=$REQUESTED_BOOT_MODE boot_mode_raw=$BOOT_MODE_RAW boot_mode=$BOOT_MODE status=$(read_param status)"

AUTO=1
if [ -r "$AUTO_FILE" ]; then
	AUTO=$(head -n 1 "$AUTO_FILE" 2>/dev/null | tr -d ' \t\r')
fi
case "$AUTO" in
0|N|n|no|off|false)
	AUTO=0
	;;
*)
	AUTO=1
	;;
esac

if [ "$AUTO" != 1 ]; then
	log_line "auto_enable=0 skipped fake_mode=$(read_param fake_mode)"
	write_state loaded_disabled
	log_modes
	exit 0
fi

if [ "$BOOT_MODE" != 1 ]; then
	log_line "auto_enable_skipped boot_mode=$BOOT_MODE need_one_mode_switch"
	write_state loaded_unarmed
	log_modes
	exit 0
fi

printf '1\n' > "/sys/module/$KO_NAME/parameters/fake_mode" 2>>"$LOG_FILE"
EN_RC=$?
sleep 1

log_line "enable rc=$EN_RC fake_mode=$(read_param fake_mode) status=$(read_param status)"

if [ "$(read_param fake_mode)" = 1 ]; then
	write_state loaded
else
	write_state loaded_unverified
fi

log_modes
exit 0