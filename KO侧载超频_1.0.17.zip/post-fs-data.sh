#!/system/bin/sh

MODDIR=${0%/*}
fix_profile_permissions() {
    for profile_file in "$MODDIR"/profiles/*/post-fs-data.sh \
                        "$MODDIR"/profiles/*/service.sh \
                        "$MODDIR"/profiles/*/service_runtime.sh \
                        "$MODDIR"/profiles/*/unified-uninstall.sh \
                        "$MODDIR"/profiles/*/uninstall.sh \
                        "$MODDIR"/profiles/*/bin/*.sh \
                        "$MODDIR"/profiles/*/bin/refresh_guard; do
        [ -f "$profile_file" ] || continue
        chmod 0755 "$profile_file" 2>/dev/null || true
    done
}
fix_profile_permissions
if [ ! -s "$MODDIR/config/selected_profile" ] && ! sh "$MODDIR/bin/oc_guard.sh" install; then
    # Keep this module enabled so service.sh can retry after clock/network setup.
    # The guard remains fail-closed and does not load a profile on failure.
    exit 0
fi
sh "$MODDIR/bin/oc_guard.sh" boot
