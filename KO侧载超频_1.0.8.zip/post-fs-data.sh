#!/system/bin/sh

MODDIR=${0%/*}
if [ ! -s "$MODDIR/config/selected_profile" ] && ! sh "$MODDIR/bin/oc_guard.sh" install; then
    CONFIG_DIR="$MODDIR/config"
    MIGRATION_FILE="$CONFIG_DIR/legacy-disabled.list"
    touch "$MODDIR/disable" 2>/dev/null || true
    if [ -r "$MIGRATION_FILE" ]; then
        while IFS= read -r old_module; do
            [ -n "$old_module" ] || continue
            if [ -d "$old_module" ] && [ -e "$old_module/disable" ]; then
                rm -f "$old_module/disable" 2>/dev/null || true
            fi
        done < "$MIGRATION_FILE"
    fi
    exit 0
fi
sh "$MODDIR/bin/oc_guard.sh" boot
